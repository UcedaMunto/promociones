--
-- NOTE:
--
-- File paths need to be edited. Search for $$PATH$$ and
-- replace it with the path to the directory containing
-- the extracted data files.
--
--
-- PostgreSQL database dump
--

-- Dumped from database version 13.6
-- Dumped by pg_dump version 13.6

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

DROP DATABASE hackton;
--
-- Name: hackton; Type: DATABASE; Schema: -; Owner: postgres
--

CREATE DATABASE hackton WITH TEMPLATE = template0 ENCODING = 'UTF8' LOCALE = 'Spanish_Spain.1252';


ALTER DATABASE hackton OWNER TO postgres;

\connect hackton

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: public; Type: SCHEMA; Schema: -; Owner: postgres
--

CREATE SCHEMA public;


ALTER SCHEMA public OWNER TO postgres;

--
-- Name: SCHEMA public; Type: COMMENT; Schema: -; Owner: postgres
--

COMMENT ON SCHEMA public IS 'standard public schema';


SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: archivo; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.archivo (
    id integer NOT NULL,
    id_tipo_archivo_id integer,
    ruta character varying(40) NOT NULL
);


ALTER TABLE public.archivo OWNER TO postgres;

--
-- Name: archivo_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.archivo_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.archivo_id_seq OWNER TO postgres;

--
-- Name: contacto; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.contacto (
    id integer NOT NULL,
    id_tipo_contacto_id integer NOT NULL,
    nombre character varying(35) NOT NULL,
    telefono character varying(10) DEFAULT NULL::character varying
);


ALTER TABLE public.contacto OWNER TO postgres;

--
-- Name: contacto_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.contacto_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.contacto_id_seq OWNER TO postgres;

--
-- Name: ctl_tipo_archivo; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.ctl_tipo_archivo (
    id integer NOT NULL,
    nombre character varying(35) NOT NULL
);


ALTER TABLE public.ctl_tipo_archivo OWNER TO postgres;

--
-- Name: ctl_tipo_archivo_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.ctl_tipo_archivo_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.ctl_tipo_archivo_id_seq OWNER TO postgres;

--
-- Name: ctl_tipo_aviso; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.ctl_tipo_aviso (
    id integer NOT NULL,
    nombre character varying(35) NOT NULL,
    activo boolean
);


ALTER TABLE public.ctl_tipo_aviso OWNER TO postgres;

--
-- Name: ctl_tipo_aviso_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.ctl_tipo_aviso_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.ctl_tipo_aviso_id_seq OWNER TO postgres;

--
-- Name: ctl_tipo_contacto; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.ctl_tipo_contacto (
    id integer NOT NULL,
    nombre character varying(35) NOT NULL
);


ALTER TABLE public.ctl_tipo_contacto OWNER TO postgres;

--
-- Name: ctl_tipo_contacto_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.ctl_tipo_contacto_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.ctl_tipo_contacto_id_seq OWNER TO postgres;

--
-- Name: ctl_tipo_promocion; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.ctl_tipo_promocion (
    id integer NOT NULL,
    nombre character varying(35) NOT NULL,
    activo boolean
);


ALTER TABLE public.ctl_tipo_promocion OWNER TO postgres;

--
-- Name: ctl_tipo_promocion_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.ctl_tipo_promocion_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.ctl_tipo_promocion_id_seq OWNER TO postgres;

--
-- Name: datos_persona; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.datos_persona (
    id integer NOT NULL,
    nombre character varying(100) NOT NULL,
    dui character varying(20) NOT NULL,
    nit character varying(17) DEFAULT NULL::character varying,
    direccion character varying(200) DEFAULT NULL::character varying,
    telefono character varying(15) DEFAULT NULL::character varying,
    celular character varying(15) DEFAULT NULL::character varying,
    fecha_nacimiento date,
    correo1 character varying(45) DEFAULT NULL::character varying,
    correo2 character varying(45) DEFAULT NULL::character varying,
    apellido character varying(35) DEFAULT NULL::character varying,
    estado integer,
    foto character varying(60) DEFAULT NULL::character varying,
    pasaporte character varying(15) DEFAULT NULL::character varying,
    giro character varying(400) DEFAULT NULL::character varying,
    ncr character varying(15) DEFAULT NULL::character varying,
    documentos character varying(50) DEFAULT NULL::character varying,
    registro_iva character varying(15) DEFAULT NULL::character varying,
    nombre_iva character varying(35) DEFAULT NULL::character varying,
    documentos2 character varying(50) DEFAULT NULL::character varying,
    documentos3 character varying(50) DEFAULT NULL::character varying
);


ALTER TABLE public.datos_persona OWNER TO postgres;

--
-- Name: datos_persona_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.datos_persona_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.datos_persona_id_seq OWNER TO postgres;

--
-- Name: departamento; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.departamento (
    id integer NOT NULL,
    nombre character varying(35) NOT NULL
);


ALTER TABLE public.departamento OWNER TO postgres;

--
-- Name: departamento_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.departamento_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.departamento_id_seq OWNER TO postgres;

--
-- Name: municipio; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.municipio (
    id integer NOT NULL,
    nombre character varying(25) NOT NULL,
    id_departamento_id integer NOT NULL
);


ALTER TABLE public.municipio OWNER TO postgres;

--
-- Name: municipio_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.municipio_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.municipio_id_seq OWNER TO postgres;

--
-- Name: persona_cliente; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.persona_cliente (
    id integer NOT NULL,
    datos_id integer NOT NULL,
    usuario_id integer,
    token_registro character varying(40) DEFAULT NULL::character varying
);


ALTER TABLE public.persona_cliente OWNER TO postgres;

--
-- Name: persona_cliente_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.persona_cliente_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.persona_cliente_id_seq OWNER TO postgres;

--
-- Name: persona_empleado; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.persona_empleado (
    id integer NOT NULL,
    datos_id integer NOT NULL,
    salario double precision,
    fecha_creacion timestamp(0) without time zone NOT NULL,
    fecha_update timestamp(0) without time zone DEFAULT NULL::timestamp without time zone,
    last_sesion date,
    activacion integer NOT NULL,
    color character varying(100) DEFAULT NULL::character varying,
    isss character varying(35) DEFAULT NULL::character varying,
    afp character varying(35) DEFAULT NULL::character varying
);


ALTER TABLE public.persona_empleado OWNER TO postgres;

--
-- Name: persona_empleado_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.persona_empleado_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.persona_empleado_id_seq OWNER TO postgres;

--
-- Name: promo_aviso; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.promo_aviso (
    id integer NOT NULL,
    id_tipo_aviso_id integer NOT NULL,
    archivo_logo_id integer NOT NULL,
    nombre character varying(60) NOT NULL,
    descripcion character varying(200) DEFAULT NULL::character varying,
    activo boolean
);


ALTER TABLE public.promo_aviso OWNER TO postgres;

--
-- Name: promo_aviso_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.promo_aviso_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.promo_aviso_id_seq OWNER TO postgres;

--
-- Name: promo_categoria; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.promo_categoria (
    id integer NOT NULL,
    nombre character varying(35) NOT NULL,
    descripcion character varying(120) DEFAULT NULL::character varying,
    activo boolean,
    archivo_logo_id integer NOT NULL,
    archivo_banner_id integer
);


ALTER TABLE public.promo_categoria OWNER TO postgres;

--
-- Name: promo_categoria_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.promo_categoria_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.promo_categoria_id_seq OWNER TO postgres;

--
-- Name: promo_contacto_establecimiento; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.promo_contacto_establecimiento (
    id integer NOT NULL,
    contacto_id integer,
    establecimiento_id integer NOT NULL
);


ALTER TABLE public.promo_contacto_establecimiento OWNER TO postgres;

--
-- Name: promo_contacto_establecimiento_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.promo_contacto_establecimiento_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.promo_contacto_establecimiento_id_seq OWNER TO postgres;

--
-- Name: promo_contacto_sucursal; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.promo_contacto_sucursal (
    id integer NOT NULL,
    id_contacto_id integer,
    sucursal_id integer NOT NULL
);


ALTER TABLE public.promo_contacto_sucursal OWNER TO postgres;

--
-- Name: promo_contacto_sucursal_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.promo_contacto_sucursal_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.promo_contacto_sucursal_id_seq OWNER TO postgres;

--
-- Name: promo_establecimiento; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.promo_establecimiento (
    id integer NOT NULL,
    nombre character varying(35) NOT NULL,
    activo boolean,
    archivo_logo_id integer NOT NULL,
    archivo_banner_id integer,
    telefono character varying(15) DEFAULT NULL::character varying,
    direccion character varying(500) DEFAULT NULL::character varying
);


ALTER TABLE public.promo_establecimiento OWNER TO postgres;

--
-- Name: promo_establecimiento_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.promo_establecimiento_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.promo_establecimiento_id_seq OWNER TO postgres;

--
-- Name: promo_establecimiento_promo_categoria; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.promo_establecimiento_promo_categoria (
    promo_establecimiento_id integer NOT NULL,
    promo_categoria_id integer NOT NULL
);


ALTER TABLE public.promo_establecimiento_promo_categoria OWNER TO postgres;

--
-- Name: promo_promociones; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.promo_promociones (
    id integer NOT NULL,
    id_tipo_id integer NOT NULL,
    fecha_inicio timestamp(0) without time zone DEFAULT NULL::timestamp without time zone,
    fecha_fin timestamp(0) without time zone DEFAULT NULL::timestamp without time zone,
    codigo character varying(20) DEFAULT NULL::character varying,
    activo boolean,
    nombre character varying(35) NOT NULL,
    descripcion character varying(200) NOT NULL
);


ALTER TABLE public.promo_promociones OWNER TO postgres;

--
-- Name: promo_promociones_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.promo_promociones_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.promo_promociones_id_seq OWNER TO postgres;

--
-- Name: promo_sucursal; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.promo_sucursal (
    id integer NOT NULL,
    id_establecimiento_id integer NOT NULL,
    id_municipio_id integer NOT NULL,
    nombre character varying(35) NOT NULL,
    activo boolean,
    direccion character varying(150) NOT NULL,
    url_ubicacion_mapa character varying(60) DEFAULT NULL::character varying NOT NULL
);


ALTER TABLE public.promo_sucursal OWNER TO postgres;

--
-- Name: promo_sucursal_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.promo_sucursal_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.promo_sucursal_id_seq OWNER TO postgres;

--
-- Name: promocion_sucursal; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.promocion_sucursal (
    id integer NOT NULL,
    id_sucursal_id integer,
    id_promocion_id integer NOT NULL,
    activo boolean
);


ALTER TABLE public.promocion_sucursal OWNER TO postgres;

--
-- Name: promocion_sucursal_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.promocion_sucursal_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.promocion_sucursal_id_seq OWNER TO postgres;

--
-- Name: tipo_contacto; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.tipo_contacto (
    id integer NOT NULL,
    nombre character varying(35) NOT NULL
);


ALTER TABLE public.tipo_contacto OWNER TO postgres;

--
-- Name: tipo_contacto_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.tipo_contacto_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.tipo_contacto_id_seq OWNER TO postgres;

--
-- Name: tipo_empleado; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.tipo_empleado (
    id integer NOT NULL,
    nombre character varying(255) NOT NULL,
    rol character varying(25) DEFAULT NULL::character varying,
    descripcion character varying(250) DEFAULT NULL::character varying
);


ALTER TABLE public.tipo_empleado OWNER TO postgres;

--
-- Name: tipo_empleado_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.tipo_empleado_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.tipo_empleado_id_seq OWNER TO postgres;

--
-- Name: usuario_cliente; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.usuario_cliente (
    id integer NOT NULL,
    usuario character varying(60) NOT NULL,
    password character varying(200) NOT NULL,
    creacion date NOT NULL,
    actualizacion date
);


ALTER TABLE public.usuario_cliente OWNER TO postgres;

--
-- Name: usuario_cliente_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.usuario_cliente_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.usuario_cliente_id_seq OWNER TO postgres;

--
-- Name: usuario_empleado; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.usuario_empleado (
    id integer NOT NULL,
    empleado_id integer,
    password character varying(200) NOT NULL,
    usuario character varying(20) NOT NULL,
    creacion date NOT NULL,
    actualizacion date
);


ALTER TABLE public.usuario_empleado OWNER TO postgres;

--
-- Name: usuario_empleado_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.usuario_empleado_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.usuario_empleado_id_seq OWNER TO postgres;

--
-- Name: usuario_empleado_tipo_empleado; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.usuario_empleado_tipo_empleado (
    usuario_empleado_id integer NOT NULL,
    tipo_empleado_id integer NOT NULL
);


ALTER TABLE public.usuario_empleado_tipo_empleado OWNER TO postgres;

--
-- Data for Name: archivo; Type: TABLE DATA; Schema: public; Owner: postgres
--

\i $$PATH$$/3258.dat

--
-- Data for Name: contacto; Type: TABLE DATA; Schema: public; Owner: postgres
--

\i $$PATH$$/3259.dat

--
-- Data for Name: ctl_tipo_archivo; Type: TABLE DATA; Schema: public; Owner: postgres
--

\i $$PATH$$/3260.dat

--
-- Data for Name: ctl_tipo_aviso; Type: TABLE DATA; Schema: public; Owner: postgres
--

\i $$PATH$$/3261.dat

--
-- Data for Name: ctl_tipo_contacto; Type: TABLE DATA; Schema: public; Owner: postgres
--

\i $$PATH$$/3262.dat

--
-- Data for Name: ctl_tipo_promocion; Type: TABLE DATA; Schema: public; Owner: postgres
--

\i $$PATH$$/3297.dat

--
-- Data for Name: datos_persona; Type: TABLE DATA; Schema: public; Owner: postgres
--

\i $$PATH$$/3263.dat

--
-- Data for Name: departamento; Type: TABLE DATA; Schema: public; Owner: postgres
--

\i $$PATH$$/3295.dat

--
-- Data for Name: municipio; Type: TABLE DATA; Schema: public; Owner: postgres
--

\i $$PATH$$/3293.dat

--
-- Data for Name: persona_cliente; Type: TABLE DATA; Schema: public; Owner: postgres
--

\i $$PATH$$/3264.dat

--
-- Data for Name: persona_empleado; Type: TABLE DATA; Schema: public; Owner: postgres
--

\i $$PATH$$/3265.dat

--
-- Data for Name: promo_aviso; Type: TABLE DATA; Schema: public; Owner: postgres
--

\i $$PATH$$/3266.dat

--
-- Data for Name: promo_categoria; Type: TABLE DATA; Schema: public; Owner: postgres
--

\i $$PATH$$/3267.dat

--
-- Data for Name: promo_contacto_establecimiento; Type: TABLE DATA; Schema: public; Owner: postgres
--

\i $$PATH$$/3291.dat

--
-- Data for Name: promo_contacto_sucursal; Type: TABLE DATA; Schema: public; Owner: postgres
--

\i $$PATH$$/3305.dat

--
-- Data for Name: promo_establecimiento; Type: TABLE DATA; Schema: public; Owner: postgres
--

\i $$PATH$$/3268.dat

--
-- Data for Name: promo_establecimiento_promo_categoria; Type: TABLE DATA; Schema: public; Owner: postgres
--

\i $$PATH$$/3289.dat

--
-- Data for Name: promo_promociones; Type: TABLE DATA; Schema: public; Owner: postgres
--

\i $$PATH$$/3301.dat

--
-- Data for Name: promo_sucursal; Type: TABLE DATA; Schema: public; Owner: postgres
--

\i $$PATH$$/3299.dat

--
-- Data for Name: promocion_sucursal; Type: TABLE DATA; Schema: public; Owner: postgres
--

\i $$PATH$$/3303.dat

--
-- Data for Name: tipo_contacto; Type: TABLE DATA; Schema: public; Owner: postgres
--

\i $$PATH$$/3269.dat

--
-- Data for Name: tipo_empleado; Type: TABLE DATA; Schema: public; Owner: postgres
--

\i $$PATH$$/3270.dat

--
-- Data for Name: usuario_cliente; Type: TABLE DATA; Schema: public; Owner: postgres
--

\i $$PATH$$/3271.dat

--
-- Data for Name: usuario_empleado; Type: TABLE DATA; Schema: public; Owner: postgres
--

\i $$PATH$$/3272.dat

--
-- Data for Name: usuario_empleado_tipo_empleado; Type: TABLE DATA; Schema: public; Owner: postgres
--

\i $$PATH$$/3273.dat

--
-- Name: archivo_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.archivo_id_seq', 74, true);


--
-- Name: contacto_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.contacto_id_seq', 12, true);


--
-- Name: ctl_tipo_archivo_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.ctl_tipo_archivo_id_seq', 2, true);


--
-- Name: ctl_tipo_aviso_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.ctl_tipo_aviso_id_seq', 3, true);


--
-- Name: ctl_tipo_contacto_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.ctl_tipo_contacto_id_seq', 2, true);


--
-- Name: ctl_tipo_promocion_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.ctl_tipo_promocion_id_seq', 4, true);


--
-- Name: datos_persona_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.datos_persona_id_seq', 1, false);


--
-- Name: departamento_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.departamento_id_seq', 3, true);


--
-- Name: municipio_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.municipio_id_seq', 6, true);


--
-- Name: persona_cliente_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.persona_cliente_id_seq', 1, false);


--
-- Name: persona_empleado_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.persona_empleado_id_seq', 1, false);


--
-- Name: promo_aviso_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.promo_aviso_id_seq', 9, true);


--
-- Name: promo_categoria_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.promo_categoria_id_seq', 12, true);


--
-- Name: promo_contacto_establecimiento_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.promo_contacto_establecimiento_id_seq', 11, true);


--
-- Name: promo_contacto_sucursal_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.promo_contacto_sucursal_id_seq', 3, true);


--
-- Name: promo_establecimiento_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.promo_establecimiento_id_seq', 14, true);


--
-- Name: promo_promociones_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.promo_promociones_id_seq', 11, true);


--
-- Name: promo_sucursal_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.promo_sucursal_id_seq', 9, true);


--
-- Name: promocion_sucursal_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.promocion_sucursal_id_seq', 25, true);


--
-- Name: tipo_contacto_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.tipo_contacto_id_seq', 1, false);


--
-- Name: tipo_empleado_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.tipo_empleado_id_seq', 1, false);


--
-- Name: usuario_cliente_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.usuario_cliente_id_seq', 1, false);


--
-- Name: usuario_empleado_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.usuario_empleado_id_seq', 1, false);


--
-- Name: archivo archivo_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.archivo
    ADD CONSTRAINT archivo_pkey PRIMARY KEY (id);


--
-- Name: contacto contacto_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.contacto
    ADD CONSTRAINT contacto_pkey PRIMARY KEY (id);


--
-- Name: ctl_tipo_archivo ctl_tipo_archivo_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.ctl_tipo_archivo
    ADD CONSTRAINT ctl_tipo_archivo_pkey PRIMARY KEY (id);


--
-- Name: ctl_tipo_aviso ctl_tipo_aviso_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.ctl_tipo_aviso
    ADD CONSTRAINT ctl_tipo_aviso_pkey PRIMARY KEY (id);


--
-- Name: ctl_tipo_contacto ctl_tipo_contacto_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.ctl_tipo_contacto
    ADD CONSTRAINT ctl_tipo_contacto_pkey PRIMARY KEY (id);


--
-- Name: ctl_tipo_promocion ctl_tipo_promocion_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.ctl_tipo_promocion
    ADD CONSTRAINT ctl_tipo_promocion_pkey PRIMARY KEY (id);


--
-- Name: datos_persona datos_persona_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.datos_persona
    ADD CONSTRAINT datos_persona_pkey PRIMARY KEY (id);


--
-- Name: departamento departamento_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.departamento
    ADD CONSTRAINT departamento_pkey PRIMARY KEY (id);


--
-- Name: municipio municipio_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.municipio
    ADD CONSTRAINT municipio_pkey PRIMARY KEY (id);


--
-- Name: persona_cliente persona_cliente_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.persona_cliente
    ADD CONSTRAINT persona_cliente_pkey PRIMARY KEY (id);


--
-- Name: persona_empleado persona_empleado_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.persona_empleado
    ADD CONSTRAINT persona_empleado_pkey PRIMARY KEY (id);


--
-- Name: promo_aviso promo_aviso_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.promo_aviso
    ADD CONSTRAINT promo_aviso_pkey PRIMARY KEY (id);


--
-- Name: promo_categoria promo_categoria_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.promo_categoria
    ADD CONSTRAINT promo_categoria_pkey PRIMARY KEY (id);


--
-- Name: promo_contacto_establecimiento promo_contacto_establecimiento_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.promo_contacto_establecimiento
    ADD CONSTRAINT promo_contacto_establecimiento_pkey PRIMARY KEY (id);


--
-- Name: promo_contacto_sucursal promo_contacto_sucursal_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.promo_contacto_sucursal
    ADD CONSTRAINT promo_contacto_sucursal_pkey PRIMARY KEY (id);


--
-- Name: promo_establecimiento promo_establecimiento_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.promo_establecimiento
    ADD CONSTRAINT promo_establecimiento_pkey PRIMARY KEY (id);


--
-- Name: promo_establecimiento_promo_categoria promo_establecimiento_promo_categoria_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.promo_establecimiento_promo_categoria
    ADD CONSTRAINT promo_establecimiento_promo_categoria_pkey PRIMARY KEY (promo_establecimiento_id, promo_categoria_id);


--
-- Name: promo_promociones promo_promociones_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.promo_promociones
    ADD CONSTRAINT promo_promociones_pkey PRIMARY KEY (id);


--
-- Name: promo_sucursal promo_sucursal_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.promo_sucursal
    ADD CONSTRAINT promo_sucursal_pkey PRIMARY KEY (id);


--
-- Name: promocion_sucursal promocion_sucursal_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.promocion_sucursal
    ADD CONSTRAINT promocion_sucursal_pkey PRIMARY KEY (id);


--
-- Name: tipo_contacto tipo_contacto_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.tipo_contacto
    ADD CONSTRAINT tipo_contacto_pkey PRIMARY KEY (id);


--
-- Name: tipo_empleado tipo_empleado_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.tipo_empleado
    ADD CONSTRAINT tipo_empleado_pkey PRIMARY KEY (id);


--
-- Name: usuario_cliente usuario_cliente_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.usuario_cliente
    ADD CONSTRAINT usuario_cliente_pkey PRIMARY KEY (id);


--
-- Name: usuario_empleado usuario_empleado_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.usuario_empleado
    ADD CONSTRAINT usuario_empleado_pkey PRIMARY KEY (id);


--
-- Name: usuario_empleado_tipo_empleado usuario_empleado_tipo_empleado_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.usuario_empleado_tipo_empleado
    ADD CONSTRAINT usuario_empleado_tipo_empleado_pkey PRIMARY KEY (usuario_empleado_id, tipo_empleado_id);


--
-- Name: idx_2143486e7b7d6e92; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_2143486e7b7d6e92 ON public.promo_sucursal USING btree (id_municipio_id);


--
-- Name: idx_2143486ef294a1fe; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_2143486ef294a1fe ON public.promo_sucursal USING btree (id_establecimiento_id);


--
-- Name: idx_2741493cbdfe2780; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_2741493cbdfe2780 ON public.contacto USING btree (id_tipo_contacto_id);


--
-- Name: idx_34ef7840a00fc9c8; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_34ef7840a00fc9c8 ON public.usuario_empleado_tipo_empleado USING btree (tipo_empleado_id);


--
-- Name: idx_34ef7840ad0015be; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_34ef7840ad0015be ON public.usuario_empleado_tipo_empleado USING btree (usuario_empleado_id);


--
-- Name: idx_3529b4823e33389b; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_3529b4823e33389b ON public.archivo USING btree (id_tipo_archivo_id);


--
-- Name: idx_451168f8279a5d5e; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_451168f8279a5d5e ON public.promo_contacto_sucursal USING btree (sucursal_id);


--
-- Name: idx_451168f87342915e; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_451168f87342915e ON public.promo_contacto_sucursal USING btree (id_contacto_id);


--
-- Name: idx_5b14cc65f5fa2e0b; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_5b14cc65f5fa2e0b ON public.promo_aviso USING btree (id_tipo_aviso_id);


--
-- Name: idx_9d363a606b505ca9; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_9d363a606b505ca9 ON public.promo_contacto_establecimiento USING btree (contacto_id);


--
-- Name: idx_9d363a6071b61351; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_9d363a6071b61351 ON public.promo_contacto_establecimiento USING btree (establecimiento_id);


--
-- Name: idx_dc263e3aab91b76d; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_dc263e3aab91b76d ON public.promo_establecimiento_promo_categoria USING btree (promo_categoria_id);


--
-- Name: idx_dc263e3ae23ba32d; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_dc263e3ae23ba32d ON public.promo_establecimiento_promo_categoria USING btree (promo_establecimiento_id);


--
-- Name: idx_e6bc69903f8890a9; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_e6bc69903f8890a9 ON public.promocion_sucursal USING btree (id_sucursal_id);


--
-- Name: idx_e6bc6990922526a6; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_e6bc6990922526a6 ON public.promocion_sucursal USING btree (id_promocion_id);


--
-- Name: idx_ecfc0c3877bac71c; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_ecfc0c3877bac71c ON public.promo_promociones USING btree (id_tipo_id);


--
-- Name: idx_fe98f5e0b3cf0305; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_fe98f5e0b3cf0305 ON public.municipio USING btree (id_departamento_id);


--
-- Name: uniq_31184dcb952be730; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX uniq_31184dcb952be730 ON public.usuario_empleado USING btree (empleado_id);


--
-- Name: uniq_390aab1377198a62; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX uniq_390aab1377198a62 ON public.persona_empleado USING btree (datos_id);


--
-- Name: uniq_5b14cc651817f2b; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX uniq_5b14cc651817f2b ON public.promo_aviso USING btree (archivo_logo_id);


--
-- Name: uniq_66da75961817f2b; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX uniq_66da75961817f2b ON public.promo_categoria USING btree (archivo_logo_id);


--
-- Name: uniq_66da7596cec8d20b; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX uniq_66da7596cec8d20b ON public.promo_categoria USING btree (archivo_banner_id);


--
-- Name: uniq_957fdf3ed6b9eea1; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX uniq_957fdf3ed6b9eea1 ON public.datos_persona USING btree (dui);


--
-- Name: uniq_e01580af1817f2b; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX uniq_e01580af1817f2b ON public.promo_establecimiento USING btree (archivo_logo_id);


--
-- Name: uniq_e01580afcec8d20b; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX uniq_e01580afcec8d20b ON public.promo_establecimiento USING btree (archivo_banner_id);


--
-- Name: uniq_f2e1c42f77198a62; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX uniq_f2e1c42f77198a62 ON public.persona_cliente USING btree (datos_id);


--
-- Name: uniq_f2e1c42fdb38439e; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX uniq_f2e1c42fdb38439e ON public.persona_cliente USING btree (usuario_id);


--
-- Name: promo_sucursal fk_2143486e7b7d6e92; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.promo_sucursal
    ADD CONSTRAINT fk_2143486e7b7d6e92 FOREIGN KEY (id_municipio_id) REFERENCES public.municipio(id);


--
-- Name: promo_sucursal fk_2143486ef294a1fe; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.promo_sucursal
    ADD CONSTRAINT fk_2143486ef294a1fe FOREIGN KEY (id_establecimiento_id) REFERENCES public.promo_establecimiento(id);


--
-- Name: contacto fk_2741493cbdfe2780; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.contacto
    ADD CONSTRAINT fk_2741493cbdfe2780 FOREIGN KEY (id_tipo_contacto_id) REFERENCES public.ctl_tipo_contacto(id);


--
-- Name: usuario_empleado fk_31184dcb952be730; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.usuario_empleado
    ADD CONSTRAINT fk_31184dcb952be730 FOREIGN KEY (empleado_id) REFERENCES public.persona_empleado(id);


--
-- Name: usuario_empleado_tipo_empleado fk_34ef7840a00fc9c8; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.usuario_empleado_tipo_empleado
    ADD CONSTRAINT fk_34ef7840a00fc9c8 FOREIGN KEY (tipo_empleado_id) REFERENCES public.tipo_empleado(id) ON DELETE CASCADE;


--
-- Name: usuario_empleado_tipo_empleado fk_34ef7840ad0015be; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.usuario_empleado_tipo_empleado
    ADD CONSTRAINT fk_34ef7840ad0015be FOREIGN KEY (usuario_empleado_id) REFERENCES public.usuario_empleado(id) ON DELETE CASCADE;


--
-- Name: archivo fk_3529b4823e33389b; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.archivo
    ADD CONSTRAINT fk_3529b4823e33389b FOREIGN KEY (id_tipo_archivo_id) REFERENCES public.ctl_tipo_archivo(id);


--
-- Name: persona_empleado fk_390aab1377198a62; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.persona_empleado
    ADD CONSTRAINT fk_390aab1377198a62 FOREIGN KEY (datos_id) REFERENCES public.datos_persona(id);


--
-- Name: promo_contacto_sucursal fk_451168f8279a5d5e; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.promo_contacto_sucursal
    ADD CONSTRAINT fk_451168f8279a5d5e FOREIGN KEY (sucursal_id) REFERENCES public.promo_sucursal(id);


--
-- Name: promo_contacto_sucursal fk_451168f87342915e; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.promo_contacto_sucursal
    ADD CONSTRAINT fk_451168f87342915e FOREIGN KEY (id_contacto_id) REFERENCES public.contacto(id);


--
-- Name: promo_aviso fk_5b14cc651817f2b; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.promo_aviso
    ADD CONSTRAINT fk_5b14cc651817f2b FOREIGN KEY (archivo_logo_id) REFERENCES public.archivo(id);


--
-- Name: promo_aviso fk_5b14cc65f5fa2e0b; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.promo_aviso
    ADD CONSTRAINT fk_5b14cc65f5fa2e0b FOREIGN KEY (id_tipo_aviso_id) REFERENCES public.ctl_tipo_aviso(id);


--
-- Name: promo_categoria fk_66da75961817f2b; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.promo_categoria
    ADD CONSTRAINT fk_66da75961817f2b FOREIGN KEY (archivo_logo_id) REFERENCES public.archivo(id);


--
-- Name: promo_categoria fk_66da7596cec8d20b; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.promo_categoria
    ADD CONSTRAINT fk_66da7596cec8d20b FOREIGN KEY (archivo_banner_id) REFERENCES public.archivo(id);


--
-- Name: promo_contacto_establecimiento fk_9d363a606b505ca9; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.promo_contacto_establecimiento
    ADD CONSTRAINT fk_9d363a606b505ca9 FOREIGN KEY (contacto_id) REFERENCES public.contacto(id);


--
-- Name: promo_contacto_establecimiento fk_9d363a6071b61351; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.promo_contacto_establecimiento
    ADD CONSTRAINT fk_9d363a6071b61351 FOREIGN KEY (establecimiento_id) REFERENCES public.promo_establecimiento(id);


--
-- Name: promo_establecimiento_promo_categoria fk_dc263e3aab91b76d; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.promo_establecimiento_promo_categoria
    ADD CONSTRAINT fk_dc263e3aab91b76d FOREIGN KEY (promo_categoria_id) REFERENCES public.promo_categoria(id) ON DELETE CASCADE;


--
-- Name: promo_establecimiento_promo_categoria fk_dc263e3ae23ba32d; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.promo_establecimiento_promo_categoria
    ADD CONSTRAINT fk_dc263e3ae23ba32d FOREIGN KEY (promo_establecimiento_id) REFERENCES public.promo_establecimiento(id) ON DELETE CASCADE;


--
-- Name: promo_establecimiento fk_e01580af1817f2b; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.promo_establecimiento
    ADD CONSTRAINT fk_e01580af1817f2b FOREIGN KEY (archivo_logo_id) REFERENCES public.archivo(id);


--
-- Name: promo_establecimiento fk_e01580afcec8d20b; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.promo_establecimiento
    ADD CONSTRAINT fk_e01580afcec8d20b FOREIGN KEY (archivo_banner_id) REFERENCES public.archivo(id);


--
-- Name: promocion_sucursal fk_e6bc69903f8890a9; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.promocion_sucursal
    ADD CONSTRAINT fk_e6bc69903f8890a9 FOREIGN KEY (id_sucursal_id) REFERENCES public.promo_sucursal(id);


--
-- Name: promocion_sucursal fk_e6bc6990922526a6; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.promocion_sucursal
    ADD CONSTRAINT fk_e6bc6990922526a6 FOREIGN KEY (id_promocion_id) REFERENCES public.promo_promociones(id);


--
-- Name: promo_promociones fk_ecfc0c3877bac71c; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.promo_promociones
    ADD CONSTRAINT fk_ecfc0c3877bac71c FOREIGN KEY (id_tipo_id) REFERENCES public.ctl_tipo_promocion(id);


--
-- Name: persona_cliente fk_f2e1c42f77198a62; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.persona_cliente
    ADD CONSTRAINT fk_f2e1c42f77198a62 FOREIGN KEY (datos_id) REFERENCES public.datos_persona(id);


--
-- Name: persona_cliente fk_f2e1c42fdb38439e; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.persona_cliente
    ADD CONSTRAINT fk_f2e1c42fdb38439e FOREIGN KEY (usuario_id) REFERENCES public.usuario_cliente(id);


--
-- Name: municipio fk_fe98f5e0b3cf0305; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.municipio
    ADD CONSTRAINT fk_fe98f5e0b3cf0305 FOREIGN KEY (id_departamento_id) REFERENCES public.departamento(id);


--
-- PostgreSQL database dump complete
--

